import { makeStyles } from '@material-ui/styles';
const classStyles = makeStyles({
  divButton: {
    display: 'flex',
    justifyContent: 'center',
  },

  container: {
    marginBottom: 5,
  },
});
export default classStyles;
