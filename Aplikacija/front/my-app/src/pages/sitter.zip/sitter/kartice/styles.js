import { makeStyles } from '@material-ui/styles';
const classStyles = makeStyles({
  constainer: {
    display: 'flex',
    // flexDirection: "column",
    alignItems: 'center',
    justifyContent: 'space-evenly',
    flex: 1,
  },

  kartica: {
    maxHeight: 330,
  },
});
export default classStyles;
